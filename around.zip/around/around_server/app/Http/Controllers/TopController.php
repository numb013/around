<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\NanpaPlace;
use Log;
class TopController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $column = 'id,place_name,genre,longitude,latitude,open_flag,ratio,icon,start_time,end_time,start_age_group,end_age_group,memo';
        $nanpa_list = NanpaPlace::select(DB::raw($column))
            ->where('open_flag', 1)
            ->get()->toArray();

        $markerData = "[";

        $pref = $request->input('pref');
        if (!empty($pref)) {
            $prefecter = config('const.pref')[$pref];
            $data = '{';
            $data .= "name:'" . $prefecter["name"] . "',";
            $data .= "lat: " . $prefecter["longitude"] . ",";
            $data .= "lng: " . $prefecter["latitude"] . ",";
            $data .= "icon: ''";
            $data .= '},';
            $markerData .= $data;
        }


        foreach ($nanpa_list as $key => $value) {
 
        $markerData .= '{';
        $markerData .= "id:'" . $value["id"] . "',";
        $markerData .= "name:'" . $value["place_name"] . "',";
        $markerData .= "lat: " . $value["longitude"] . ",";
        $markerData .= "lng: " . $value["latitude"] . ",";
        $markerData .= "icon: 'images/girl_0" . $value["icon"] . ".png',";
        $markerData .= "genre: '" . config('const.genre')[$value["genre"]] . "',";
        $markerData .= "ratio: '" . config('const.ratio')[$value["ratio"]] . "',";
        $markerData .= "time: '" . config('const.time')[$value["start_time"]] . '~' . config('const.time')[$value["end_time"]] . "',";
        $markerData .= "age_group: '" . config('const.age_group')[$value["start_age_group"]] . '~' . config('const.age_group')[$value["end_age_group"]] . "',";
        $markerData .= "memo: " . $value["memo"] . "'aa'";
        $markerData .= '},';

        }
        $markerData1 = $markerData . ']';
        $inputs['markerData'] = $markerData1;

Log::debug($inputs['markerData']);
        //フォーム入力画ページのviewを表示
        return view('index', ['input' => $inputs,]);
    }

}
